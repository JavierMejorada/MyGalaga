

class Game:
    def __init__(self):
        pass

    def iniciar(self):
        pass
