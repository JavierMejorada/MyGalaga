
Ancho_pantalla = 800
Alto_pantalla = 600
Velocidad_del_jugador = 20
Velocidad_del_enemigo = 5
Numero_de_enemigos_fila = 5
Numero_de_filas_enemigos = 3
PUNTAJES = "puntajes.json"
